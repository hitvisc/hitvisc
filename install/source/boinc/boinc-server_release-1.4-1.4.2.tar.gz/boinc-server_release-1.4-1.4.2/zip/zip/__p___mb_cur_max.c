#ifdef __cplusplus
extern "C" int __p___mb_cur_max(void);
#else
extern int __p___mb_cur_max(void);
#endif
int __p___mb_cur_max(void) { return 2; }
