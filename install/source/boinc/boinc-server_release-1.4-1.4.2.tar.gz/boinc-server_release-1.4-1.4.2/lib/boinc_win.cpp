// boinc_win.cpp : source file that includes just the standard includes
// $(TargetName).pch will be the pre-compiled header
// boinc_win.obj will contain the pre-compiled type information

#include "boinc_win.h"
